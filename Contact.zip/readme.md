# Portfolio Website V1.0

Welcome to my first functioning website, please see below for all current functionality and plans for future updates!

Thanks for Visiting!

Cooper

## Current Functionality 

All Pages are currently functional, following the design theorum of *mobile first!*

## Future updates 

* As new languages are learnt I plan to add new pages/functionality
* With access to libraries and animation functionality certain pages will be changed entirely with the mindset of simpler code/ ease of reading.
* Plan to add fully functioning contact page that with API will send emails/contact details directly to myself for enquiries for networking purposes.

## References

Certain functionality I have used free resources all my images are royalty free from [Freepik](https://freepik.com)

I have utilised tutorials from [W3schools](https://w3schools.com)

And my icons/svg's are from [Phosphor](https://phosphoricons.com)


Thankyou for visiting my page and will continue to update in future!

